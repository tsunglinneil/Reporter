# coding=utf-8
from Crawler import FlaskNbaRoute

# ============== Main ==============
FlaskNbaRoute.start()
